"""Portable checks of public input-quality commands and their documented limits."""

from __future__ import annotations

import importlib.util
import json
import subprocess
from pathlib import Path

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
PRESSURE_HARNESS = REPOSITORY_ROOT / "scripts/verify_input_resource_pressure.py"
EXPECTED_LIMITS = {
    "CSV_RAW_BYTES": 67_108_864,
    "CSV_RECORD_CHARACTERS": 1_024,
    "CSV_FIELD_CHARACTERS": 256,
    "CSV_DATA_ROWS": 1_000_000,
    "NPZ_RAW_BYTES": 33_554_432,
    "NPZ_CENTRAL_DIRECTORY_BYTES": 16_384,
    "NPY_HEADER_BYTES": 4_096,
    "NPY_ELEMENTS": 1_000_000,
    "NPZ_MEMBER_UNCOMPRESSED_BYTES": 8_004_108,
    "NPZ_TOTAL_UNCOMPRESSED_BYTES": 16_008_216,
}


def test_pressure_harness_runs_read_only_with_fresh_workers(tmp_path: Path) -> None:
    assert PRESSURE_HARNESS.is_file()
    spec = importlib.util.spec_from_file_location("pressure_harness", PRESSURE_HARNESS)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    assert module.FORMATS == ("CSV", "NPZ")
    assert module.SIZES == (10_000, 100_000, 250_000, 1_000_000)
    assert module.DTYPE == "float64"
    assert module.NPZ_STORAGE == "NPZ_STORED"
    assert module.REPEAT_COUNT == 1
    assert module.RSS_SAMPLE_INTERVAL_SECONDS == 0.001

    output = tmp_path / "pressure.json"
    completed = subprocess.run(
        [
            "uv",
            "run",
            "--no-project",
            "--python",
            "3.11",
            "--with",
            "numpy==2.4.6",
            "--with",
            "psutil==7.0.0",
            "python",
            str(PRESSURE_HARNESS),
            "--formats",
            "CSV",
            "NPZ",
            "--sizes",
            "10",
            "--output",
            str(output),
        ],
        cwd=REPOSITORY_ROOT,
        check=False,
        capture_output=True,
        text=True,
    )
    assert completed.returncode == 0, completed.stderr
    observed = json.loads(output.read_text("utf-8"))
    assert observed["execution"]["freshSubprocessPerCase"] is True
    assert observed["execution"]["parallel"] is False
    assert observed["execution"]["temporaryInputsRetained"] is False
    assert [(case["format"], case["rowsOrElements"]) for case in observed["cases"]] == [
        ("CSV", 10),
        ("NPZ", 10),
    ]
    assert all(len(case["inputSha256"]) == 64 for case in observed["cases"])


def test_readme_documents_the_input_contract_without_claim_inflation() -> None:
    readme = (REPOSITORY_ROOT / "README.md").read_text(encoding="utf-8")
    normalized = " ".join(readme.split())
    assert "## Load bounded CSV and NPZ inputs" in readme
    assert "strict UTF-8 two-field CSV" in readme
    assert "quoted fields cannot contain CR or LF" in readme
    assert "`source`/`source.npy` and `target`/`target.npy`" in readme
    for reason, limit in EXPECTED_LIMITS.items():
        assert f"`{reason}` | {limit:,}" in readme
    assert "INPUT_RESOURCE_LIMIT_EXCEEDED_V1 reason=<CODE> limit=<INTEGER>" in readme
    assert (
        "These input-loading limits are independent of and not interchangeable with the "
        "`B`, `C`, `N`, and `S` in-memory execution budget."
        in normalized
    )
    assert (
        "This is not streaming or out-of-core support, a security certification, M6 "
        "scientific evidence, release readiness, or SoftwareX submission readiness."
        in normalized
    )
