"""Literal checks for the bounded verifier extraction, independent of the builder."""

from __future__ import annotations

import importlib
import inspect
import sys
from collections.abc import Callable
from types import FrameType, FunctionType

import pytest
from test_verifier_integration_v2 import (
    _adjacent_fault_complete_case,
    _replicate_execution_terminal_literal_case,
)

import selcal.contracts_v2 as contracts_v2


def test_typed_primitives_are_on_the_public_verification_path() -> None:
    try:
        primitives = importlib.import_module("selcal._verifier_primitives_v2")
    except ModuleNotFoundError:
        pytest.fail("typed verifier primitives have not been extracted")
    captured = inspect.getclosurevars(contracts_v2.verify_calibration_result).nonlocals
    assert type(captured["primitive_ops"]) is primitives.VerifierPrimitiveOpsV2
    assert "_verify_result_vector_against_plan" not in captured
    assert primitives.VerifierPrimitiveOpsV2._fields == (
        "require_sha256", "require_diagnostics", "read_exact_slots", "verify_selection",
        "verify_complete_vector", "verify_failure_vector", "verify_replicate_prefix",
        "verify_replicate_suffix", "verify_terminal",
    )


def test_public_verification_executes_every_captured_primitive() -> None:
    captured = inspect.getclosurevars(contracts_v2.verify_calibration_result).nonlocals
    ops = captured["primitive_ops"]
    operations = {name: getattr(ops, name) for name in ops._fields}
    assert all(type(operation) is FunctionType for operation in operations.values())
    names_by_code = {operation.__code__: name for name, operation in operations.items()}
    assert len(names_by_code) == len(operations) == 9
    calls: set[str] = set()

    def profile(frame: FrameType, event: str, _arg: object) -> None:
        if event == "call" and frame.f_code in names_by_code:
            calls.add(names_by_code[frame.f_code])

    # Literal input graphs are built without the production result builder.
    cases = (_adjacent_fault_complete_case(), _replicate_execution_terminal_literal_case())
    previous = sys.getprofile()
    sys.setprofile(profile)
    runtime_verifier: Callable[[object, object], object] = contracts_v2.verify_calibration_result
    try:
        for result, resolution in cases:
            assert runtime_verifier(result, resolution) is None
    finally:
        sys.setprofile(previous)
    assert sys.getprofile() is previous
    assert calls == set(operations)
