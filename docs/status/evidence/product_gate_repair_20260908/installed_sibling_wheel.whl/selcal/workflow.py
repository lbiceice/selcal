"""Public file-to-record workflow over the unchanged scientific v2 core.

A terminal record captures input, request and complete result content. It is not
an execution checkpoint, historical authentication or independent validation.
"""

from __future__ import annotations

import hashlib
import html
import json
import platform
import re
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

from selcal import (
    __version__,
    calibrate_selected_family,
    resolve_plan_v2,
    verify_calibration_result,
)
from selcal.canonical_v2 import scientific_plan_v2_sha256
from selcal.contracts_v2 import CalibrationResult, SelCalV2Error
from selcal.input_resources import INPUT_LIMITS_V1, read_regular_file_snapshot
from selcal.inputs import LoadedInput, load_csv, load_npz
from selcal.resolution_v2 import PlanResolutionV2
from selcal.result_wire import decode_calibration_result, encode_calibration_result
from selcal.workflow_config import WorkflowConfig, decode_workflow_config, encode_workflow_config
from selcal.workflow_store import read_record, write_record

CONFIG_BYTES = 65_536


class WorkflowError(ValueError):
    """A path-free application consistency error with a stable code."""

    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__(code)


@dataclass(frozen=True)
class WorkflowRecord:
    """Checked terminal content, not a live execution or resume capability."""

    config: WorkflowConfig
    result: CalibrationResult
    metadata: dict[str, Any]


def _limit(max_bytes: int) -> None:
    if type(max_bytes) is not int or max_bytes < 1:
        raise WorkflowError("invalid_limit")


def _json(data: object) -> bytes:
    return (
        json.dumps(data, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n"
    ).encode()


def _software_identity() -> dict[str, Any]:
    package = Path(__file__).parent
    sources = {}
    for path in sorted(package.rglob("*.py")):
        if path.is_symlink():
            raise WorkflowError("unsupported_source")
        sources[path.relative_to(package).as_posix()] = hashlib.sha256(
            path.read_bytes()
        ).hexdigest()
    if not sources:
        raise WorkflowError("source_unavailable")
    return {
        "selcal_version": __version__,
        "python_version": platform.python_version(),
        "numpy_version": np.__version__,
        "source_files": sources,
    }


def _load(path: Path, config: WorkflowConfig) -> LoadedInput:
    if config.source_format == "csv":
        assert config.source_column is not None and config.target_column is not None
        return load_csv(
            path,
            source_column=config.source_column,
            target_column=config.target_column,
            candidates=config.request.candidates,
        )
    return load_npz(path, candidates=config.request.candidates)


def _files(
    input_path: str | Path, config_path: str | Path
) -> tuple[WorkflowConfig, PlanResolutionV2, LoadedInput, bytes]:
    config_bytes = read_regular_file_snapshot(
        config_path, raw_limit=CONFIG_BYTES, reason="WORKFLOW_CONFIG_BYTES"
    )
    config = decode_workflow_config(config_bytes)
    resolution = resolve_plan_v2(config.request)
    loaded = _load(Path(input_path), config)
    raw_limit = (
        INPUT_LIMITS_V1.csv_raw_bytes
        if config.source_format == "csv"
        else INPUT_LIMITS_V1.npz_raw_bytes
    )
    raw = read_regular_file_snapshot(input_path, raw_limit=raw_limit, reason="WORKFLOW_INPUT_BYTES")
    if hashlib.sha256(raw).hexdigest() != loaded.raw_input_sha256:
        raise WorkflowError("input_changed")
    return config, resolution, loaded, raw


def validate_files(input_path: str | Path, config_path: str | Path) -> dict[str, Any]:
    """Validate actual input/configuration without running surrogate calibration."""
    config, resolution, loaded, _ = _files(input_path, config_path)
    return {
        "sample_count": int(loaded.pair.source.size),
        "planned_replicates": config.request.replicates,
        "raw_input_sha256": loaded.raw_input_sha256,
        "semantic_input_sha256": loaded.semantic_input_sha256,
        "scientific_plan_sha256": scientific_plan_v2_sha256(resolution.plan),
        "validation_scope": "input_and_plan_not_execution_admission_or_scientific_validity",
    }


def run_files(
    input_path: str | Path, config_path: str | Path, output_path: str | Path, *, max_bytes: int
) -> CalibrationResult:
    """Run a real calibration and exclusively save a complete terminal record.

    Computation uses the existing in-memory admission limits. max_bytes separately
    limits the record; it does not promise a process memory bound or early pause.
    """
    _limit(max_bytes)
    if Path(output_path).exists() or Path(output_path).is_symlink():
        raise FileExistsError("output already exists")
    config, resolution, loaded, raw = _files(input_path, config_path)
    software = _software_identity()
    result = calibrate_selected_family(loaded.pair, resolution)
    verify_calibration_result(result, resolution)
    if software != _software_identity():
        raise WorkflowError("source_changed")
    metadata = {
        "schema": "selcal.workflow-record.v1",
        "raw_input_sha256": loaded.raw_input_sha256,
        "semantic_input_sha256": result.semantic_input_sha256,
        "scientific_plan_sha256": result.scientific_plan_sha256,
        "software": software,
    }
    write_record(
        output_path,
        {
            "input": raw,
            "request": encode_workflow_config(config),
            "result": encode_calibration_result(result, max_bytes=max_bytes),
            "metadata": _json(metadata),
        },
        max_bytes=max_bytes,
    )
    return result


def _metadata(raw: bytes) -> dict[str, Any]:
    def unique(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            if key in result:
                raise WorkflowError("invalid_metadata")
            result[key] = value
        return result

    def forbidden(value: str) -> None:
        raise WorkflowError("invalid_metadata")

    try:
        value = json.loads(raw.decode("utf-8"), object_pairs_hook=unique, parse_constant=forbidden)
        keys = {
            "schema",
            "raw_input_sha256",
            "semantic_input_sha256",
            "scientific_plan_sha256",
            "software",
        }
        if type(value) is not dict or set(value) != keys:
            raise WorkflowError("invalid_metadata")
        if value["schema"] != "selcal.workflow-record.v1":
            raise WorkflowError("invalid_metadata")
        for key in keys - {"schema", "software"}:
            if type(value[key]) is not str or re.fullmatch("[0-9a-f]{64}", value[key]) is None:
                raise WorkflowError("invalid_metadata")
        software = value["software"]
        if type(software) is not dict or set(software) != {
            "selcal_version",
            "python_version",
            "numpy_version",
            "source_files",
        }:
            raise WorkflowError("invalid_metadata")
        for key in ("selcal_version", "python_version", "numpy_version"):
            if type(software[key]) is not str or not software[key] or len(software[key]) > 256:
                raise WorkflowError("invalid_metadata")
        sources = software["source_files"]
        if type(sources) is not dict or not sources:
            raise WorkflowError("invalid_metadata")
        for name, digest in sources.items():
            if (
                type(name) is not str
                or not re.fullmatch(r"[A-Za-z0-9_/]+\.py", name)
                or name.startswith("/")
                or "//" in name
                or type(digest) is not str
                or re.fullmatch("[0-9a-f]{64}", digest) is None
            ):
                raise WorkflowError("invalid_metadata")
        return value
    except (ValueError, TypeError, RecursionError) as error:
        raise WorkflowError("invalid_metadata") from error


def _read_context(
    record_path: str | Path, max_bytes: int
) -> tuple[WorkflowRecord, LoadedInput, PlanResolutionV2, bytes]:
    _limit(max_bytes)
    members = read_record(record_path, max_bytes=max_bytes)
    try:
        config = decode_workflow_config(members["request"])
        metadata = _metadata(members["metadata"])
        result = decode_calibration_result(members["result"], max_bytes=max_bytes)
        resolution = resolve_plan_v2(config.request)
        # Reuse the same strict file loader; never consult the original input path.
        with tempfile.TemporaryDirectory(prefix="selcal-read-") as folder:
            path = Path(folder) / ("input." + config.source_format)
            path.write_bytes(members["input"])
            loaded = _load(path, config)
        if (
            metadata["raw_input_sha256"] != loaded.raw_input_sha256
            or metadata["semantic_input_sha256"] != loaded.semantic_input_sha256
            or result.semantic_input_sha256 != loaded.semantic_input_sha256
            or metadata["scientific_plan_sha256"] != result.scientific_plan_sha256
        ):
            raise WorkflowError("identity_mismatch")
        verify_calibration_result(result, resolution)
    except (ValueError, TypeError, SelCalV2Error) as error:
        raise WorkflowError("invalid_record_content") from error
    return WorkflowRecord(config, result, metadata), loaded, resolution, members["result"]


def read_workflow(record_path: str | Path, *, max_bytes: int) -> WorkflowRecord:
    """Read a captured terminal and verify input/plan/result consistency, not replay."""
    return _read_context(record_path, max_bytes)[0]


def result_summary(result: CalibrationResult) -> dict[str, Any]:
    """Return explicit scientific status and decision fields without dropping failures."""
    selection = result.observed_selection
    return {
        "status": result.status.value,
        "failure_stage": None if result.failure_stage is None else result.failure_stage.value,
        "planned_replicates": result.planned_replicates,
        "retained_replicates": len(result.replicates),
        "exceedance_count": result.exceedance_count,
        "failure_count": result.failure_count,
        "p_value": result.p_value,
        "selected_candidate": None if selection is None else selection.selected_candidate,
        "decision_statistic": None if selection is None else selection.decision_statistic,
        "tied_candidates": None if selection is None else list(selection.tied_candidates),
        "reject_null": result.reject_null,
        "exceedance_bound_low": result.exceedance_bound_low,
        "exceedance_bound_high": result.exceedance_bound_high,
        "semantic_input_sha256": result.semantic_input_sha256,
        "scientific_plan_sha256": result.scientific_plan_sha256,
    }


def verify_record(
    record_path: str | Path, *, max_bytes: int, replay: bool = False
) -> dict[str, Any]:
    """Optionally execute an explicit full replay; never authenticate past execution."""
    if type(replay) is not bool:
        raise WorkflowError("invalid_replay_option")
    record, loaded, resolution, saved = _read_context(record_path, max_bytes)
    if replay:
        if record.metadata["software"] != _software_identity():
            raise WorkflowError("environment_mismatch")
        actual = calibrate_selected_family(loaded.pair, resolution)
        if encode_calibration_result(actual, max_bytes=max_bytes) != saved:
            raise WorkflowError("replay_mismatch")
    return {
        **result_summary(record.result),
        "replay": "MATCH" if replay else "NOT_PERFORMED",
        "verification_scope": "input_plan_result_consistency",
        "historical_execution_authenticated": False,
    }


def report_record(
    record_path: str | Path, output_path: str | Path, *, max_bytes: int
) -> dict[str, Any]:
    """Render an exclusive HTML report from checked content, without scientific replay."""
    record = read_workflow(record_path, max_bytes=max_bytes)
    result = record.result
    summary = {**result_summary(result), "replay": "NOT_PERFORMED"}
    body = [
        '<!doctype html><html lang="en"><meta charset="utf-8">',
        "<title>SelCal calibration report</title><style>"
        "body{max-width:960px;margin:2rem auto;padding:0 1rem;font:16px system-ui;color:#172b4d}"
        "pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f3f5f7;padding:1rem}"
        "section{border-top:1px solid #ccd3dc}h2{margin-top:2rem}"
        "</style><body><h1>SelCal calibration report</h1>",
        "<p>Input/plan/result consistency checked; replay NOT_PERFORMED. "
        "Recorded content is not authenticated historical execution.</p>",
        "<p>NOT_EVALUABLE is not evidence of no effect or non-significance.</p>",
        "<h2>Summary</h2><pre>",
        html.escape(json.dumps(summary, indent=2)),
        "</pre>",
        "<h2>Configuration</h2><pre>",
        html.escape(encode_workflow_config(record.config).decode()),
        "</pre><h2>Observed candidates</h2><pre>",
        html.escape(repr(result.observed_results)),
        "</pre><h2>Observed selection</h2><pre>",
        html.escape(repr(result.observed_selection)),
        "</pre><h2>Replicates</h2>",
    ]
    for outcome in result.replicates:
        body.extend(
            (
                f'<section data-replicate-id="{outcome.replicate_id}"><h3>Replicate '
                f"{outcome.replicate_id}</h3><pre>",
                html.escape(repr(outcome)),
                "</pre></section>",
            )
        )
    body.extend(
        (
            "<h2>Diagnostics</h2><pre>",
            html.escape(repr(result.diagnostics)),
            "</pre><h2>Recorded software identity (not authentication)</h2><pre>",
            html.escape(json.dumps(record.metadata["software"], indent=2)),
            "</pre></body></html>",
        )
    )
    payload = "\n".join(body).encode("utf-8")
    if len(payload) > max_bytes:
        raise WorkflowError("report_size_limit")
    with Path(output_path).open("xb") as stream:
        stream.write(payload)
    return summary


def doctor() -> dict[str, Any]:
    """Report this runtime, without claiming unexecuted tests or scientific validation."""
    import sqlite3

    return {
        "selcal_version": __version__,
        "python_version": platform.python_version(),
        "numpy_version": np.__version__,
        "sqlite_version": sqlite3.sqlite_version,
        "sqlite_deserialize": hasattr(sqlite3.Connection, "deserialize"),
        "checkpoint_resume": "NOT_IMPLEMENTED",
        "scientific_validation": "NOT_EXECUTED",
    }
