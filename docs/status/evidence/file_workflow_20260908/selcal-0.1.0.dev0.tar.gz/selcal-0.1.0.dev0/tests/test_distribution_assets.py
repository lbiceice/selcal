"""Inspect real build outputs without writing build metadata into the checkout.

These checks cover shipped assets, not the portability of repository-only review
tests that still require internal evidence under docs/status or docs/superpowers.
"""

from __future__ import annotations

import re
import shutil
import subprocess
import sys
import tarfile
import tomllib
import zipfile
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture(scope="module")
def distributions(tmp_path_factory: pytest.TempPathFactory) -> tuple[Path, Path, Path]:
    workspace = tmp_path_factory.mktemp("distribution-assets")
    source = workspace / "source"
    shutil.copytree(
        ROOT,
        source,
        ignore=shutil.ignore_patterns(
            ".git",
            ".venv",
            "__pycache__",
            "*.pyc",
            "*.egg-info",
            ".pytest_cache",
            ".ruff_cache",
            ".mypy_cache",
            "build",
            "dist",
            "_build",
        ),
    )
    output = workspace / "dist"
    completed = subprocess.run(
        [sys.executable, "-m", "build", "--outdir", str(output), str(source)],
        cwd=workspace,
        capture_output=True,
        text=True,
        timeout=180,
        check=False,
    )
    assert completed.returncode == 0, completed.stdout + completed.stderr
    sdists = list(output.glob("*.tar.gz"))
    wheels = list(output.glob("*.whl"))
    assert len(sdists) == len(wheels) == 1
    return source, sdists[0], wheels[0]


def _sdist_files(path: Path) -> dict[str, bytes]:
    with tarfile.open(path, "r:gz") as archive:
        files = {}
        for member in archive.getmembers():
            if member.isfile():
                content = archive.extractfile(member)
                assert content is not None
                files[member.name.partition("/")[2]] = content.read()
        return files


def test_sdist_contains_documented_user_assets(distributions: tuple[Path, Path, Path]) -> None:
    source, sdist, _ = distributions
    required = {
        ".gitignore",
        "README.md",
        "pyproject.toml",
        "uv.lock",
        "examples/basic_selection_aware_calibration.py",
        "examples/binned_nette_block_shuffle.py",
        "examples/fail_closed_not_evaluable.py",
        "examples/save_and_read_result.py",
        "scripts/benchmark_in_memory.py",
        "scripts/plot_in_memory_benchmark.py",
        "scripts/m6_pearson_diagnostic.py",
        "scripts/compare_pearson_diagnostic.py",
        "docs/api/conf.py",
        "docs/api/index.rst",
        "docs/api/architecture.rst",
        "docs/api/performance.rst",
        "docs/api/public_api.rst",
        "docs/api/usage.rst",
        "docs/benchmarks/in_memory_standard_20260831.json",
        "docs/benchmarks/in_memory_standard_20260831_figure.svg",
    }
    readme = (source / "README.md").read_text(encoding="utf-8")
    required.update(re.findall(r"(?:examples|scripts)/[A-Za-z0-9_./-]+\.py", readme))
    required.update(
        path.relative_to(source).as_posix()
        for path in (source / "examples" / "workflow").glob("*")
        if path.suffix in {".csv", ".json"} and path.is_file()
    )
    files = _sdist_files(sdist)
    assert not (missing := required - files.keys()), f"sdist missing user assets: {sorted(missing)}"
    for name in required:
        assert files[name] == (source / name).read_bytes(), name


def test_sdist_preserves_source_and_test_inputs(distributions: tuple[Path, Path, Path]) -> None:
    source, sdist, _ = distributions
    required = {
        path.relative_to(source).as_posix()
        for directory in (source / "src" / "selcal", source / "tests")
        for path in directory.rglob("*")
        if path.is_file() and path.suffix in {".py", ".json", ".csv"}
    }
    files = _sdist_files(sdist)
    assert not (missing := required - files.keys()), (
        f"sdist missing source/test files: {sorted(missing)}"
    )
    for name in required:
        assert files[name] == (source / name).read_bytes(), name


def test_distributions_exclude_internal_reviews_and_generated_outputs(
    distributions: tuple[Path, Path, Path],
) -> None:
    _, sdist, wheel = distributions
    with zipfile.ZipFile(wheel) as archive:
        names = set(archive.namelist()) | _sdist_files(sdist).keys()
    for name in names:
        assert "docs/superpowers/" not in name, name
        assert "docs/status/" not in name, name
        assert "docs/api/_build/" not in name, name
        assert "__pycache__/" not in name, name
        assert not name.endswith((".pyc", ".pyo", ".DS_Store")), name


def test_wheel_from_sdist_preserves_runtime_and_declared_documentation(
    distributions: tuple[Path, Path, Path],
) -> None:
    source, _, wheel = distributions
    pyproject = tomllib.loads((source / "pyproject.toml").read_text(encoding="utf-8"))
    project = pyproject["project"]
    data_prefix = f"{project['name']}-{project['version']}.data/data/"
    with zipfile.ZipFile(wheel) as archive:
        for path in (source / "src" / "selcal").rglob("*.py"):
            name = path.relative_to(source / "src").as_posix()
            assert archive.read(name) == path.read_bytes(), name
        for destination, paths in pyproject["tool"]["setuptools"]["data-files"].items():
            for relative in paths:
                name = data_prefix + destination + "/" + Path(relative).name
                assert archive.read(name) == (source / relative).read_bytes(), name
