from __future__ import annotations

import json
from pathlib import Path

from scripts.audit_repository_hygiene import AuditFinding, audit_repository, main

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]


def _write_minimal_release_surface(root: Path) -> None:
    package = root / "src" / "selcal"
    package.mkdir(parents=True)
    (package / "__init__.py").write_text("VALUE = 1\n", encoding="utf-8")
    (root / "README.md").write_text(
        "# Example\n\n```python\nprint('result')\n```\n", encoding="utf-8"
    )
    (root / "pyproject.toml").write_text("[project]\nname = 'selcal'\n", encoding="utf-8")


def test_current_release_surface_passes_repository_hygiene_gate() -> None:
    assert audit_repository(REPOSITORY_ROOT) == ()


def test_production_python_debug_call_is_rejected(tmp_path: Path) -> None:
    _write_minimal_release_surface(tmp_path)
    source = tmp_path / "src" / "selcal" / "core.py"
    source.write_text("def run() -> None:\n    print('debug')\n", encoding="utf-8")

    assert audit_repository(tmp_path) == (
        AuditFinding(
            rule="PYTHON_DEBUG_CALL",
            path="src/selcal/core.py",
            line=2,
            detail="print",
        ),
    )


def test_machine_local_absolute_path_is_rejected(tmp_path: Path) -> None:
    _write_minimal_release_surface(tmp_path)
    source = tmp_path / "src" / "selcal" / "core.py"
    source.write_text('DATA = "/Users/alice/private/input.csv"\n', encoding="utf-8")

    assert audit_repository(tmp_path) == (
        AuditFinding(
            rule="ABSOLUTE_MACHINE_PATH",
            path="src/selcal/core.py",
            line=1,
            detail="/Users/alice/",
        ),
    )


def test_credential_shaped_material_is_rejected_without_echoing_secret(
    tmp_path: Path,
) -> None:
    _write_minimal_release_surface(tmp_path)
    secret = "sk-" + "A" * 32
    (tmp_path / "README.md").write_text(f'api_key = "{secret}"\n', encoding="utf-8")

    assert audit_repository(tmp_path) == (
        AuditFinding(
            rule="CREDENTIAL_MATERIAL",
            path="README.md",
            line=1,
            detail="OPENAI_STYLE_TOKEN",
        ),
    )
    assert secret not in repr(audit_repository(tmp_path))


def test_symlink_in_release_surface_is_rejected_without_following_it(tmp_path: Path) -> None:
    _write_minimal_release_surface(tmp_path)
    outside = tmp_path / "outside.py"
    outside.write_text("VALUE = 2\n", encoding="utf-8")
    link = tmp_path / "src" / "selcal" / "linked.py"
    link.symlink_to(outside)

    assert audit_repository(tmp_path) == (
        AuditFinding(
            rule="SYMLINK_IN_RELEASE_SURFACE",
            path="src/selcal/linked.py",
            line=0,
            detail="not followed",
        ),
    )


def test_internal_design_tree_is_not_part_of_release_surface(tmp_path: Path) -> None:
    _write_minimal_release_surface(tmp_path)
    internal = tmp_path / "docs" / "superpowers" / "review.md"
    internal.parent.mkdir(parents=True)
    internal.write_text('/Users/alice/internal-only\n', encoding="utf-8")

    assert audit_repository(tmp_path) == ()


def test_status_documents_are_part_of_the_portable_release_surface(tmp_path: Path) -> None:
    _write_minimal_release_surface(tmp_path)
    status = tmp_path / "docs" / "status" / "readiness.md"
    status.parent.mkdir(parents=True)
    status.write_text("worktree: /Users/alice/private/checkout\n", encoding="utf-8")

    assert audit_repository(tmp_path) == (
        AuditFinding(
            rule="ABSOLUTE_MACHINE_PATH",
            path="docs/status/readiness.md",
            line=1,
            detail="/Users/alice/",
        ),
    )


def test_dependency_lock_is_part_of_portable_release_surface(tmp_path: Path) -> None:
    _write_minimal_release_surface(tmp_path)
    (tmp_path / "uv.lock").write_text(
        'source = "/Users/alice/private/wheelhouse"\n', encoding="utf-8"
    )

    assert audit_repository(tmp_path) == (
        AuditFinding(
            rule="ABSOLUTE_MACHINE_PATH",
            path="uv.lock",
            line=1,
            detail="/Users/alice/",
        ),
    )


def test_generated_documentation_sources_are_part_of_release_surface(
    tmp_path: Path,
) -> None:
    _write_minimal_release_surface(tmp_path)
    api_doc = tmp_path / "docs" / "api" / "usage.rst"
    api_doc.parent.mkdir(parents=True)
    api_doc.write_text(
        "Developer checkout: /Users/alice/private/checkout\n",
        encoding="utf-8",
    )

    assert audit_repository(tmp_path) == (
        AuditFinding(
            rule="ABSOLUTE_MACHINE_PATH",
            path="docs/api/usage.rst",
            line=1,
            detail="/Users/alice/",
        ),
    )


def test_benchmark_receipts_are_part_of_portable_release_surface(tmp_path: Path) -> None:
    _write_minimal_release_surface(tmp_path)
    receipt = tmp_path / "docs" / "benchmarks" / "receipt.json"
    receipt.parent.mkdir(parents=True)
    receipt.write_text(
        '{"checkout": "/Users/alice/private/checkout"}\n',
        encoding="utf-8",
    )

    assert audit_repository(tmp_path) == (
        AuditFinding(
            rule="ABSOLUTE_MACHINE_PATH",
            path="docs/benchmarks/receipt.json",
            line=1,
            detail="/Users/alice/",
        ),
    )


def test_benchmark_vector_figures_are_part_of_portable_release_surface(
    tmp_path: Path,
) -> None:
    _write_minimal_release_surface(tmp_path)
    figure = tmp_path / "docs" / "benchmarks" / "figure.svg"
    figure.parent.mkdir(parents=True)
    figure.write_text(
        '<svg><text>/Users/alice/private/checkout</text></svg>\n',
        encoding="utf-8",
    )

    assert audit_repository(tmp_path) == (
        AuditFinding(
            rule="ABSOLUTE_MACHINE_PATH",
            path="docs/benchmarks/figure.svg",
            line=1,
            detail="/Users/alice/",
        ),
    )


def test_command_line_result_is_machine_readable_and_redacts_secret(
    tmp_path: Path,
    capsys,
) -> None:
    _write_minimal_release_surface(tmp_path)
    secret = "ghp_" + "B" * 32
    (tmp_path / "README.md").write_text(f'token = "{secret}"\n', encoding="utf-8")

    assert main([str(tmp_path)]) == 1
    output = capsys.readouterr().out
    payload = json.loads(output)

    assert payload == {
        "findings": [
            {
                "detail": "GITHUB_STYLE_TOKEN",
                "line": 1,
                "path": "README.md",
                "rule": "CREDENTIAL_MATERIAL",
            }
        ],
        "repository": str(tmp_path.resolve()),
        "status": "FAIL",
    }
    assert secret not in output
