from __future__ import annotations

import argparse
import ast
import json
import os
import re
import stat
from dataclasses import asdict, dataclass
from pathlib import Path

_TEXT_SUFFIXES = {".json", ".md", ".py", ".rst", ".svg", ".toml", ".yaml", ".yml"}
_MACHINE_PATH_PATTERNS = (
    re.compile(r"/(?:Users|home)/[^/\s\"']+/"),
    re.compile(r"/var/folders/"),
    re.compile(r"/tmp/"),
    re.compile(r"[A-Za-z]:\\Users\\[^\\\s\"']+\\"),
)
_CREDENTIAL_PATTERNS = (
    ("AWS_ACCESS_KEY", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("GITHUB_STYLE_TOKEN", re.compile(r"\bgh[pousr]_[A-Za-z0-9]{20,}\b")),
    ("OPENAI_STYLE_TOKEN", re.compile(r"\bsk-[A-Za-z0-9_-]{20,}\b")),
    (
        "PRIVATE_KEY_BLOCK",
        re.compile(r"-----BEGIN (?:RSA|EC|OPENSSH|DSA) PRIVATE KEY-----"),
    ),
    (
        "CREDENTIAL_ASSIGNMENT",
        re.compile(
            r"(?i)\b(?:api[_-]?key|password|secret|access[_-]?token|auth[_-]?token)"
            r"\s*[:=]\s*[\"'][^\"'\s]{8,}[\"']"
        ),
    ),
)


@dataclass(frozen=True, order=True)
class AuditFinding:
    rule: str
    path: str
    line: int
    detail: str


def _relative(root: Path, path: Path) -> str:
    return path.relative_to(root).as_posix()


def _release_surface_paths(root: Path) -> tuple[Path, ...]:
    candidates: set[Path] = set()
    for relative in ("README.md", "pyproject.toml", "uv.lock"):
        path = root / relative
        if path.exists() or path.is_symlink():
            candidates.add(path)

    roots = (
        root / "src" / "selcal",
        root / "examples",
        root / "docs" / "architecture",
        root / "docs" / "api",
        root / "docs" / "benchmarks",
        root / "docs" / "provenance",
        root / "docs" / "status",
        root / "scripts",
    )
    auditor = root / "scripts" / "audit_repository_hygiene.py"
    for surface_root in roots:
        if not surface_root.is_dir():
            continue
        for path in surface_root.rglob("*"):
            if path == auditor or path.name == ".DS_Store" or "__pycache__" in path.parts:
                continue
            if path.suffix.lower() in _TEXT_SUFFIXES and (path.is_file() or path.is_symlink()):
                candidates.add(path)
    return tuple(sorted(candidates, key=lambda path: _relative(root, path)))


def _read_utf8_regular_file(path: Path) -> str:
    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)
    descriptor = os.open(path, flags)
    try:
        if not stat.S_ISREG(os.fstat(descriptor).st_mode):
            raise OSError("release-surface entry is not a regular file")
        chunks: list[bytes] = []
        while chunk := os.read(descriptor, 1024 * 1024):
            chunks.append(chunk)
    finally:
        os.close(descriptor)
    return b"".join(chunks).decode("utf-8")


def _text_findings(relative: str, text: str) -> list[AuditFinding]:
    findings: list[AuditFinding] = []
    for line_number, line in enumerate(text.splitlines(), start=1):
        for pattern in _MACHINE_PATH_PATTERNS:
            match = pattern.search(line)
            if match is not None:
                findings.append(
                    AuditFinding(
                        rule="ABSOLUTE_MACHINE_PATH",
                        path=relative,
                        line=line_number,
                        detail=match.group(),
                    )
                )
                break
        for credential_name, pattern in _CREDENTIAL_PATTERNS:
            if pattern.search(line) is not None:
                findings.append(
                    AuditFinding(
                        rule="CREDENTIAL_MATERIAL",
                        path=relative,
                        line=line_number,
                        detail=credential_name,
                    )
                )
                break
    return findings


def _call_name(call: ast.Call) -> str | None:
    if isinstance(call.func, ast.Name) and call.func.id in {"breakpoint", "print"}:
        return call.func.id
    if (
        isinstance(call.func, ast.Attribute)
        and call.func.attr == "set_trace"
        and isinstance(call.func.value, ast.Name)
        and call.func.value.id == "pdb"
    ):
        return "pdb.set_trace"
    return None


def _production_python_findings(relative: str, text: str) -> list[AuditFinding]:
    try:
        tree = ast.parse(text)
    except SyntaxError as error:
        return [
            AuditFinding(
                rule="PYTHON_PARSE_ERROR",
                path=relative,
                line=error.lineno or 0,
                detail=error.msg,
            )
        ]

    findings: list[AuditFinding] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and (name := _call_name(node)) is not None:
            findings.append(
                AuditFinding(
                    rule="PYTHON_DEBUG_CALL",
                    path=relative,
                    line=node.lineno,
                    detail=name,
                )
            )
    return findings


def audit_repository(repository_root: Path) -> tuple[AuditFinding, ...]:
    root = repository_root.resolve(strict=True)
    findings: list[AuditFinding] = []
    for path in _release_surface_paths(root):
        relative = _relative(root, path)
        if path.is_symlink():
            findings.append(
                AuditFinding(
                    rule="SYMLINK_IN_RELEASE_SURFACE",
                    path=relative,
                    line=0,
                    detail="not followed",
                )
            )
            continue
        try:
            text = _read_utf8_regular_file(path)
        except (OSError, UnicodeDecodeError) as error:
            findings.append(
                AuditFinding(
                    rule="UNREADABLE_RELEASE_SURFACE_FILE",
                    path=relative,
                    line=0,
                    detail=type(error).__name__,
                )
            )
            continue
        findings.extend(_text_findings(relative, text))
        if relative.startswith("src/selcal/") and path.suffix == ".py":
            findings.extend(_production_python_findings(relative, text))
    return tuple(sorted(findings))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Audit SelCal's release surface for local paths, debug calls and secrets."
    )
    parser.add_argument("repository", nargs="?", default=".")
    arguments = parser.parse_args(argv)
    repository = Path(arguments.repository).resolve(strict=True)
    findings = audit_repository(repository)
    payload = {
        "findings": [asdict(finding) for finding in findings],
        "repository": str(repository),
        "status": "FAIL" if findings else "PASS",
    }
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 1 if findings else 0


if __name__ == "__main__":
    raise SystemExit(main())
